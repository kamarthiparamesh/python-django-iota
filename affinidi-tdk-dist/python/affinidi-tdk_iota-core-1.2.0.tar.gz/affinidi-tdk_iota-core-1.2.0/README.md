## @affinidi/iota-core

### Installation

```bash
npm install @affinidi-tdk/iota-core
```

### Usage

Head over to [Affinidi Iota Framework documentation](https://docs.affinidi.com/services/iota-framework) page to better understand how the service works.

For details on how to use this library please head over to [iota-core documentation](https://docs.affinidi.com/dev-tools/affinidi-tdk/libraries/iota-core) page.
